Conversion functions between ISO country identifiers.
-----------------------------------------------------

Using country data derived from wikipedia, this package provides conversion functions for countries, country-codes, and continents.

See https://github.com/TuneLab/pycountries for more information.


