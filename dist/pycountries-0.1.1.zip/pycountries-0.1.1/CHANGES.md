## pycountries-python Changes Log
## TUNE Multiverse Countries Library for Python 3.0
## Incorporate TUNE Multiverse Integration services.
#### Update:  $Date: 2016-07-18 15:06:23 PDT $
===

Here you can see the full list of changes between each `pycountries-python` release.

Version 0.1.0
-------------
* Initial release
