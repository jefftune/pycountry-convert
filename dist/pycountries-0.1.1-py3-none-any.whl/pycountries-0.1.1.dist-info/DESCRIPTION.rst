Python country data derived from wikipedia.
-------------------------------------------

DESCRIPTION

Python converstion function for countries, country-codes, and continents.

See https://github.com/TuneLab/pycountries for
more information.

LICENSE TUNE Multiverse Countries Library is distributed under the
MIT License

