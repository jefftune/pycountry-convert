## pycountry-convert Authors
## Countries conversion functions for Python 2.7 and 3.0
===

## pycountry-convert Authors
==========================================

We'd like to thank the following people who have contributed to the `pycountry-convert` repository.

- Jeff Tanner <jefft@tune.com>
- Zaq? Wiedmann <zaq@tune.com>

## pycountry-convert-python Maintainers
==========================================

- Jeff Tanner <jefft@tune.com>
- Zaq? Wiedmann <zaq@tune.com>
