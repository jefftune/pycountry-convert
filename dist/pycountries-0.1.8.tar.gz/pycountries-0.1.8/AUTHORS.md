## pycountries Authors
## Countries Library for Python 3.0
## Update:  $Date: 2016-07-18 15:06:23 PDT $
===

## pycountries Authors
==========================================

We'd like to thank the following people who have contributed to the `pycountries-python` repository.

- Lee Brown <lee@tune.com>
- Jeff Tanner <jefft@tune.com>
- Zaq? Wiedmann <zaq@tune.com>

## pycountries-python Maintainers
==========================================

- Jeff Tanner <jefft@tune.com>
- Zaq? Wiedmann <zaq@tune.com>
