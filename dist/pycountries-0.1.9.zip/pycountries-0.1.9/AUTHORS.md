## pycountries Authors
## Countries conversion functions for Python 2.7 and 3.0
===

## pycountries Authors
==========================================

We'd like to thank the following people who have contributed to the `pycountries` repository.

- Jeff Tanner <jefft@tune.com>
- Zaq? Wiedmann <zaq@tune.com>

## pycountries-python Maintainers
==========================================

- Jeff Tanner <jefft@tune.com>
- Zaq? Wiedmann <zaq@tune.com>
