Python country data derived from wikipedia.
-------------------------------------------

DESCRIPTION

Python open-source package for countries, country-codes, continents, and territories.

See https://github.com/TuneLab/pycountries for
more information.

LICENSE TUNE Multiverse Countries Library is distributed under the
MIT License

