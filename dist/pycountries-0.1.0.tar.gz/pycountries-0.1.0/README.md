# pycountries
Python open-source package for country codes, countries, and continents conversion tools.


Available functions:

Convert country code alpha_2 to continent:
`convert_country_2_code_to_continent()`

Convert country code alpha_2 to country name:
`convert_country_2_code_to_country_name()`

Convert country name to country code alpha_2:
`convert_country_name_to_country_2_code()`

Convert country code alpha_3 to country code alpha_2:
`convert_country_3_code_to_country_2_code()`